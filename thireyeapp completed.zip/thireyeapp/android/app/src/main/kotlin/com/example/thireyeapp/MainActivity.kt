package com.example.thireyeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
