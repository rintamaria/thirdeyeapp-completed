#import <Flutter/Flutter.h>

@interface FlutterTtsPlugin : NSObject<FlutterPlugin>
@end
